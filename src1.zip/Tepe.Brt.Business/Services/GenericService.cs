﻿using Tepe.Brt.Data.Entities;
using Tepe.Brt.Data.Repositories;

namespace Tepe.Brt.Business.Services
{
    public interface IGenericService
    {

        #region Patient
        Task<IEnumerable<PatientEntity>> GetPatientList();
        Task<PatientEntity> GetPatientDetailById(Guid patientId);
        Task<PatientEntity> SavePatientDetail(PatientEntity model);
        Task<PatientEntity> UpdatePatientDetail(PatientEntity model);
        Task DeletePatient(Guid patientId);
        #endregion

        #region Recommendation
        Task<IEnumerable<RecommendationEntity>> GetRecommendationList();
        Task<RecommendationEntity> GetRecommendationDetailById(Guid recommendationId);
        Task<RecommendationEntity> SaveRecommendationDetail(RecommendationEntity model);
        Task<RecommendationEntity> UpdateRecommendationDetail(RecommendationEntity model);
        Task DeleteRecommendation(Guid recommendationId);
        #endregion

        #region RecoItems
        Task<IEnumerable<RecoItemEntity>> GetRecoItemList();
        Task<RecoItemEntity> GetRecoItemDetailById(Guid recoItemId);
        Task<RecoItemEntity> SaveRecoItemDetail(RecoItemEntity model);
        Task<RecoItemEntity> UpdateRecoItemDetail(RecoItemEntity model);
        Task DeleteRecoItem(Guid recoItemId);
        #endregion

    }
    public class GenericService : IGenericService
    {
        private readonly IGenericRepository _userRepository;
        public GenericService(IGenericRepository userRepository)
        {
            _userRepository = userRepository;
        }

        #region Patient
        public async Task<PatientEntity> GetPatientDetailById(Guid patientId)
        {
            return await _userRepository.GetPatientDetailById(patientId);
        }
        public async Task<IEnumerable<PatientEntity>> GetPatientList()
        {
            return await _userRepository.GetPatientList();
        }
        public async Task<PatientEntity> SavePatientDetail(PatientEntity model)
        {
            return await _userRepository.SavePatientDetail(model);
        }
        public async Task<PatientEntity> UpdatePatientDetail(PatientEntity model)
        {
            return await _userRepository.UpdatePatientDetail(model);
        }
        public async Task DeletePatient(Guid patientId)
        {
            await _userRepository.DeletePatient(patientId);
        }
        #endregion

        #region Recommendation
        public async Task<RecommendationEntity> GetRecommendationDetailById(Guid recommendationId)
        {
            return await _userRepository.GetRecommendationDetailById(recommendationId);
        }
        public async Task<IEnumerable<RecommendationEntity>> GetRecommendationList()
        {
            return await _userRepository.GetRecommendationList();
        }
        public async Task<RecommendationEntity> SaveRecommendationDetail(RecommendationEntity model)
        {
            return await _userRepository.SaveRecommendationDetail(model);
        }
        public async Task<RecommendationEntity> UpdateRecommendationDetail(RecommendationEntity model)
        {
            return await _userRepository.UpdateRecommendationDetail(model);
        }
        public async Task DeleteRecommendation(Guid recommendationId)
        {
            await _userRepository.DeleteRecommendation(recommendationId);
        }
        #endregion

        #region RecoItem
        public async Task<RecoItemEntity> GetRecoItemDetailById(Guid recoItemId)
        {
            return await _userRepository.GetRecoItemDetailById(recoItemId);
        }
        public async Task<IEnumerable<RecoItemEntity>> GetRecoItemList()
        {
            return await _userRepository.GetRecoItemList();
        }
        public async Task<RecoItemEntity> SaveRecoItemDetail(RecoItemEntity model)
        {
            return await _userRepository.SaveRecoItemDetail(model);
        }
        public async Task<RecoItemEntity> UpdateRecoItemDetail(RecoItemEntity model)
        {
            return await _userRepository.UpdateRecoItemDetail(model);
        }
        public async Task DeleteRecoItem(Guid recoItemId)
        {
            await _userRepository.DeleteRecoItem(recoItemId);
        }
        #endregion

    }
}
