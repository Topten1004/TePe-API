﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Tepe.Brt.Api.ViewModels;
using Tepe.Brt.Business.Services;
using Tepe.Brt.Data.Entities;

namespace Tepe.Brt.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class RecommendationController : ControllerBase
    {

        private readonly IGenericService _genericService;
        private readonly IMapper _mapper;
        private readonly ILogger<RecommendationController> _logger;
        private readonly IWebHostEnvironment _env;
        private string localDirectoryPath = "files/images/";

        public RecommendationController(ILogger<RecommendationController> logger, IMapper mapper, IGenericService genericService, IWebHostEnvironment env)
        {
            _logger = logger;
            _mapper = mapper;
            _genericService = genericService;
            _env = env;
        }

        #region Recommendation

        // Method to get the list of the recommendations
        [HttpGet(Name = "GetRecommendations")]
        public async Task<IResult> GetRecommendationsList()
        {
            var result = await _genericService.GetRecommendationList();
            IEnumerable<RecommendationVM> recommendations = _mapper.Map<IEnumerable<RecommendationVM>>(result);
            if (recommendations == null)
            {
                return Results.NotFound();
            }
            return Results.Ok(recommendations);
        }

        // Method to get the recommendation detail by recommendation ID
        [HttpGet]
        [Route("GetRecommendationDetailById")]
        public async Task<IResult> GetRecommendationDetailById(Guid recommendationsId)
        {
            var result = await _genericService.GetRecommendationDetailById(recommendationsId);
            RecommendationVM recommendation = _mapper.Map<RecommendationVM>(result);
            if (recommendation == null)
            {
                return Results.NotFound();
            }
            return Results.Ok(recommendation);
        }

        // Method to save the recommendation detail
        [HttpPost(Name = "SaveRecommendationDetail")]
        public async Task<IResult> SaveRecommendationDetail(RecommendationVM model)
        {
            if (model.ImageFile != null)
            {
                var directoryPath = Path.Combine(_env.WebRootPath, localDirectoryPath);
                var uniqueFileName = GetUniqueFileName(model.ImageFile.FileName);
                var filePath = Path.Combine(directoryPath, uniqueFileName);
                model.ImageFile.CopyTo(new FileStream(filePath, FileMode.Create));
                //model.Image = localDirectoryPath + uniqueFileName;
            }
            RecommendationEntity recommendations = _mapper.Map<RecommendationEntity>(model);
            var result = await _genericService.SaveRecommendationDetail(recommendations);
            if (result == null)
            {
                return Results.NotFound();
            }
            return Results.Ok(recommendations);
        }

        // Method to update the recommendation detail
        [HttpPut(Name = "UpdateRecommendationDetail")]
        public async Task<IResult> UpdateRecommendationDetail(RecommendationVM model)
        {
            if (model.ImageFile != null)
            {
                var directoryPath = Path.Combine(_env.WebRootPath, localDirectoryPath);
                var uniqueFileName = GetUniqueFileName(model.ImageFile.FileName);
                var filePath = Path.Combine(directoryPath, uniqueFileName);
                model.ImageFile.CopyTo(new FileStream(filePath, FileMode.Create));
                //model.Image = localDirectoryPath + uniqueFileName;
            }
            RecommendationEntity recommendations = _mapper.Map<RecommendationEntity>(model);
            var result = await _genericService.UpdateRecommendationDetail(recommendations);
            if (result == null)
            {
                return Results.NotFound();
            }
            return Results.Ok(recommendations);
        }

        // Method to delete the recommendation detail
        [HttpDelete(Name = "DeleteRecommendation")]
        public async Task<IResult> DeleteRecommendation(Guid recommendationsId)
        {
            await _genericService.DeleteRecommendation(recommendationsId);
            return Results.Ok();
        }
        #endregion

        // Method to generate a unique path of the image file
        private string GetUniqueFileName(string fileName)
        {
            fileName = Path.GetFileName(fileName);
            return Path.GetFileNameWithoutExtension(fileName)
                      + "_"
                      + Guid.NewGuid().ToString().Substring(0, 4)
                      + Path.GetExtension(fileName);
        }
    }
}
