﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tepe.Brt.Api.ViewModels
{
    public class RecommendationVM
    {
        public RecommendationVM()
        {
            RecoItems = new List<RecoItemVM>();
        }

        public Guid Id { get; set; }

        public string? Comment { get; set; }

        [NotMapped]
        public IFormFile? ImageFile { get; set; }

        public string? TeethImage { get; set; }

        public string? Bridge { get; set; }

        public string? Missing { get; set; }

        public string? Lang { get; set; }

        public string? MarketID { get; set; }

        public Guid PatientID { get; set; }

        public virtual IEnumerable<RecoItemVM> RecoItems { get; set; }
    }
}
