﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Tepe.Brt.Api.ViewModels;
using Tepe.Brt.Business.Services;
using Tepe.Brt.Data.Entities;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Clients;

namespace Tepe.Brt.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PatientController : ControllerBase
    {

        private readonly IGenericService _genericService;
        private readonly INotificationService _notificationService;
        private readonly IMapper _mapper;
        private readonly ILogger<PatientController> _logger;
        private readonly IConfiguration _config;
        public PatientController(IConfiguration config, ILogger<PatientController> logger, IMapper mapper, IGenericService genericService, INotificationService notificationService)
        {
            _config = config;
            _logger = logger;
            _mapper = mapper;
            _genericService = genericService;
            _notificationService = notificationService;
        }

        #region Patient

        // Method to get the list of the patients
        [HttpGet(Name = "GetPatients")]
        public async Task<IResult> GetPatientsList()
        {
            var result = await _genericService.GetPatientList();
            IEnumerable<PatientVM> patients = _mapper.Map<IEnumerable<PatientVM>>(result);
            if (patients == null)
            {
                return Results.NotFound();
            }
            return Results.Ok(patients);
        }

        // Method to get the patient detail by patient ID
        [HttpGet]
        [Route("GetPatientDetailById")]
        public async Task<IResult> GetPatientDetailById(Guid patientId)
        {
            var result = await _genericService.GetPatientDetailById(patientId);
            PatientVM patient = _mapper.Map<PatientVM>(result);
            if (patient == null)
            {
                return Results.NotFound();
            }
            return Results.Ok(patient);
        }

        // Method to save the patient detail
        [HttpPost(Name = "SavePatientDetail")]
        public async Task<IResult> SavePatientDetail([FromForm] PatientModel model)
        {
            if (ModelState.IsValid)
            {
                PatientVM patientModel = new PatientVM();
                patientModel.Email = model.email;
                patientModel.PhoneNumber = model.phone_number;

                PatientEntity patients = _mapper.Map<PatientEntity>(patientModel);
                var result = await _genericService.SavePatientDetail(patients);

                RecommendationVM recommend = new RecommendationVM();
                recommend.Comment = model.comment;
                recommend.TeethImage = model.teeth_image;
                recommend.Bridge = String.Join(", ", model.bridge.Select(p => p.ToString()).ToArray());
                recommend.Missing = String.Join(", ", model.missing.Select(p => p.ToString()).ToArray());
                recommend.Lang = model.lang;
                recommend.MarketID = model.market_id;
                recommend.PatientID = patients.Id;

                RecommendationEntity recommendEntity = _mapper.Map<RecommendationEntity>(recommend);
                var result_recommend = await _genericService.SaveRecommendationDetail(recommendEntity);

                if (result_recommend == null)
                {
                    return Results.NotFound();
                }

                var data = JsonConvert.DeserializeObject<List<ItemModel>>(model.recommendations);

                foreach (var item in data)
                {
                    RecoItemVM recoItem = new RecoItemVM();
                    recoItem.CatImgName = item.cat_img_name;
                    recoItem.Title = item.title;
                    recoItem.Description = item.description;
                    recoItem.Size = item.size;
                    recoItem.Area = item.area;
                    recoItem.RecommendationID = recommendEntity.Id;

                    RecoItemEntity recoItems = _mapper.Map<RecoItemEntity>(recoItem);
                    var result_recoItems = await _genericService.SaveRecoItemDetail(recoItems);

                    if (result_recoItems == null)
                    {
                        return Results.NotFound();
                    }
                }

                if (result == null)
                {
                    return Results.NotFound();
                }

                string str = await _notificationService.SendNotification(model.body, model.sender, model.receiver);

                Console.WriteLine(str);

                if (str == "accepted" || str == "queued")
                {
                    return Results.Ok(patients);
                }
                else
                {
                    return Results.BadRequest();
                }

            }
            else
            {
                return Results.BadRequest();
            }
        }

        // Method to update the patient detail
        [HttpPut(Name = "UpdatePatientDetail")]
        public async Task<IResult> UpdatePatientDetail(PatientVM model)
        {
            PatientEntity patients = _mapper.Map<PatientEntity>(model);
            var result = await _genericService.UpdatePatientDetail(patients);
            if (result == null)
            {
                return Results.NotFound();
            }
            return Results.Ok(patients);
        }

        // Method to delete the patient detail
        [HttpDelete(Name = "DeletePatient")]
        public async Task<IResult> DeletePatient(Guid patientId)
        {
            await _genericService.DeletePatient(patientId);
            return Results.Ok();
        }
        #endregion
    }

    public class PatientModel
    {
        public string? body { get; set; }
        public string? sender { get; set; }
        public string? receiver { get; set; }
        public string? email { get; set; }
        public string? phone_number { get; set; }
        public string? comment { get; set; }

        public string? recommendations { get; set; } = string.Empty;

        public List<int> missing { get; set; } = new List<int>();

        public List<int> bridge { get; set; } = new List<int>();

        public string? lang { get; set; } = string.Empty;

        public string? market_id { get; set; } = string.Empty;

        public string? teeth_image { get; set; }
    }

    public class ItemModel
    {
        public string cat_img_name { get; set; } = string.Empty;

        public string title { get; set; } = string.Empty;

        public string description { get; set; } = string.Empty;

        public string size { get; set; } = string.Empty;

        public string area { get; set; } = string.Empty;
    }
}
