﻿using Tepe.Brt.Data.Entities;

namespace Tepe.Brt.Api.ViewModels
{
    public class RecoItemVM
    {
        public Guid Id { get; set; }

        public string? CatImgName { get; set; }

        public string? Title { get; set; }

        public string? Description { get; set; }

        public string? Size { get; set; }

        public string? Area { get; set; }

        public Guid RecommendationID { get; set; }
    }
}
