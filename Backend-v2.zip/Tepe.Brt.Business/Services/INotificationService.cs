﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tepe.Brt.Data.Entities;
using Microsoft.Extensions.Options;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Microsoft.Extensions.Configuration;
using Twilio.Clients;

namespace Tepe.Brt.Business.Services
{
    public interface INotificationService
    {
        Task<string> SendNotification(string body, string sender, string receiver);
    }

    public class TwilioSmsOptions
    {
        public const string TwilioSms = "TwilioSms";
        public string? Sid { get; set; }
        public string? AuthToken { get; set; }
    }
    public class TwilioSmsNotificationService : INotificationService
    {
        private readonly HttpClient _httpClient;
        private readonly TwilioSmsOptions _options;
        private readonly IConfiguration _config;

        public TwilioSmsNotificationService(IConfiguration config, IOptions<TwilioSmsOptions> options, HttpClient httpClient)
        {
            _config = config;
            _options = options.Value;
            _httpClient = httpClient;
        }


        public async Task<string> SendNotification(string body, string sender, string receiver)
        {
            // TODO: Call Twilio SMS service
            var client = new TwilioRestClient(_config["TwilioSms:Sid"], _config["TwilioSms:AuthToken"]);

            var message = MessageResource.Create(
                body: body,
                to: new Twilio.Types.PhoneNumber(receiver),
                from: new Twilio.Types.PhoneNumber(sender),
                client: client
            );

            return message.Status.ToString();
        }

        public Task<bool> SendNotification(RecommendationEntity recommendation)
        {
            throw new NotImplementedException();
        }
    }
}
