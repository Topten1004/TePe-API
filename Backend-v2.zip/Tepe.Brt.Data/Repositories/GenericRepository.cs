﻿using Microsoft.EntityFrameworkCore;
using Tepe.Brt.Data.Entities;

namespace Tepe.Brt.Data.Repositories
{
    public interface IGenericRepository
    {

        #region Patient
        Task<IEnumerable<PatientEntity>> GetPatientList();
        Task<PatientEntity> GetPatientDetailById(Guid patientId);
        Task<PatientEntity> SavePatientDetail(PatientEntity model);
        Task<PatientEntity> UpdatePatientDetail(PatientEntity model);
        Task DeletePatient(Guid patientId);
        #endregion

        #region Recommendation
        Task<IEnumerable<RecommendationEntity>> GetRecommendationList();
        Task<RecommendationEntity> GetRecommendationDetailById(Guid recommendationId);
        Task<RecommendationEntity> SaveRecommendationDetail(RecommendationEntity model);
        Task<RecommendationEntity> UpdateRecommendationDetail(RecommendationEntity model);
        Task DeleteRecommendation(Guid recommendationId);
        #endregion

        #region RecoItem
        Task<IEnumerable<RecoItemEntity>> GetRecoItemList();
        Task<RecoItemEntity> GetRecoItemDetailById(Guid recoItemId);
        Task<RecoItemEntity> SaveRecoItemDetail(RecoItemEntity model);
        Task<RecoItemEntity> UpdateRecoItemDetail(RecoItemEntity model);
        Task DeleteRecoItem(Guid recoItemId);
        #endregion

    }

    public class GenericRepository : IGenericRepository
    {
        private readonly ApplicationDbContext _model;
        public GenericRepository(ApplicationDbContext model)
        {
            _model = model;
        }

        #region Patient
        public async Task<IEnumerable<PatientEntity>> GetPatientList()
        {
            var model = await _model.Patients.Include(x => x.Recommendations).ToListAsync();
            return model;
        }
        public async Task<PatientEntity> GetPatientDetailById(Guid patientId)
        {
            return await _model.Patients.FindAsync(patientId);
        }
        public async Task<PatientEntity> SavePatientDetail(PatientEntity model)
        {
            await _model.Patients.AddAsync(model);
            await _model.SaveChangesAsync();
            return model;
        }
        public async Task<PatientEntity> UpdatePatientDetail(PatientEntity model)
        {
            //_model.Entry(model).State = EntityState.Modified;
            _model.Update(model);
            await _model.SaveChangesAsync();
            return model;
        }
        public async Task DeletePatient(Guid patientId)
        {
            PatientEntity patient = await _model.Patients.FindAsync(patientId);
            if (patient != null)
            {
                _model.Remove(patient);
                await _model.SaveChangesAsync();
            }
        }
        #endregion

        #region Recommendation
        public async Task<IEnumerable<RecommendationEntity>> GetRecommendationList()
        {
            var model = await _model.Recommendations.ToListAsync();
            return model;
        }
        public async Task<RecommendationEntity> GetRecommendationDetailById(Guid recommendationId)
        {
            return await _model.Recommendations.Include(x => x.RecoItems).FirstOrDefaultAsync(x => x.Id == recommendationId);
        }
        public async Task<RecommendationEntity> SaveRecommendationDetail(RecommendationEntity model)
        {
            await _model.Recommendations.AddAsync(model);
            await _model.SaveChangesAsync();
            return model;
        }
        public async Task<RecommendationEntity> UpdateRecommendationDetail(RecommendationEntity model)
        {
            //_model.Entry(model).State = EntityState.Modified;
            _model.Update(model);
            await _model.SaveChangesAsync();
            return model;
        }
        public async Task DeleteRecommendation(Guid recommendationId)
        {
            RecommendationEntity recommendation = await _model.Recommendations.FindAsync(recommendationId);
            if (recommendation != null)
            {
                _model.Remove(recommendation);
                await _model.SaveChangesAsync();
            }
        }
        #endregion

        #region RecoItem
        public async Task<IEnumerable<RecoItemEntity>> GetRecoItemList()
        {
            var model = await _model.RecoItems.ToListAsync();
            return model;
        }
        public async Task<RecoItemEntity> GetRecoItemDetailById(Guid recoItemId)
        {
            return await _model.RecoItems.FindAsync(recoItemId);
        }
        public async Task<RecoItemEntity> SaveRecoItemDetail(RecoItemEntity model)
        {
            await _model.RecoItems.AddAsync(model);
            await _model.SaveChangesAsync();
            return model;
        }
        public async Task<RecoItemEntity> UpdateRecoItemDetail(RecoItemEntity model)
        {
            _model.Update(model);
            await _model.SaveChangesAsync();
            return model;
        }
        public async Task DeleteRecoItem(Guid recoItemId)
        {
            RecoItemEntity recoItem = await _model.RecoItems.FindAsync(recoItemId);
            if (recoItem != null)
            {
                _model.Remove(recoItem);
                await _model.SaveChangesAsync();
            }
        }
        #endregion

    }
}
