# Introduction

Tepe brush recommendation tool developed by [KAN.SE](https://kan.se/) with Material-UI

# Getting Started

1. Installation process
   - Intall [Nodejs](https://nodejs.org/en/)
   - Run 'npm install' or 'yarn install'
   - Start dev server with 'npm run start' or 'yarn start'
2. Deployment process
   - Run 'npm run build' or 'yarn build'
